package ca.polymtl.inf8480.tp1.client;

public class FakeServer {
	void execute(byte[] bytes) {
	}
}